# CSE3033_Project2_2023

Feyzullah Asıllıoğlu - 150121021
Kadir Bat - 150120012
Muhammed Talha Karagül - 150120055

To compile code:    gcc mainSetup.c -o myShell
To run code:        ./myShell

!!! Our problem in project: 
If we run an application in the background while doing the exit part, myshell: appears directly on our screen and thus the background is set equal to zero. In this case, we do not use the exit function when there is a background. Because every time I type exit to myshell, the background is set equal to zero with the code you gave us.